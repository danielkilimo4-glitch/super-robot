# Clips.io Creator Studio

A mobile-friendly browser editing interface for the Clips.io project.

## Run locally
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Run `python -m http.server 8080`.
4. Visit `http://localhost:8080`.

You can also add `index.html` to the root of your GitHub repository and enable GitHub Pages.

## Included
- Video upload and drag-and-drop
- In-browser preview and seeking
- Start/end trim controls
- Output presets for 9:16, 1:1, 16:9 and 4:5
- Quality options and optional mute
- MP4 export using FFmpeg.wasm

## Notes
The source video is processed in the browser and is not uploaded to a server by this page. The first export downloads the FFmpeg WebAssembly engine from jsDelivr, so an internet connection is needed. Large files may exceed available memory, especially on mobile devices.

This is a front-end editing interface. It does not yet connect the existing Python ClipWatcher livestream monitor, AI highlight detection, cloud projects, user accounts, or caption generation. Those features need a secure backend and platform-compliant integrations. Do not put API keys in browser JavaScript.
