# Clips.io Web Studio

This adds a browser-based editing companion to the existing Python ClipWatcher project.

## What works in this first web release

- Responsive desktop and mobile interface
- Import a local video by file picker or drag-and-drop
- Preview and seek through the video
- Set clip start and end times
- Export an MP4 trim
- Export in original, 9:16, 1:1, 16:9, or 4:5 aspect ratios
- Choose a quality preset
- Download the exported clip
- Video processing happens in the browser using FFmpeg WebAssembly

## Run locally

No build step is required.

```bash
python -m http.server 8080
```

Open `http://localhost:8080`.

You can also enable GitHub Pages for the repository root after adding `index.html`.

## Important architecture note

The existing `clipwatcher.py` remains intact. It is a Python livestream monitoring and highlight-detection engine. This static web studio does not yet start that Python process or connect to Twitch/YouTube live chat. That requires a separately hosted backend/API, authentication, job queue, and platform-compliant stream integrations. Do not expose API keys in browser JavaScript.

## Browser requirements and limitations

- A modern browser with WebAssembly support is required.
- The FFmpeg WebAssembly engine is downloaded from jsDelivr on first export, so internet access is needed for the export engine.
- Large files may be slow or fail on phones because browser memory is limited.
- This MVP exports local uploaded media. It does not download videos from third-party platforms.
- Verify that you have permission to edit and publish the source video.

## Existing Python engine

Keep the current Python files and configuration. The web app is an additional interface, not a replacement for ClipWatcher.
